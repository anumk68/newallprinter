

<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" >

    <title></title>



    <style>

     a.num{

         color: white;

         text-decoration: none;

     }

    </style>

</head>

<body>

 <div class="container">

     <div class="row">

          

     </div>

 </div>

</body>

</html>

<div id="modalContent">

   <h4 style="margin-bottom: 20px;">Welcome to Printer Support</h4>

   <p style="color:black"><b>Your Support Ticket No.: <span id="ticket_no"></span></b> </p>

   <p>We acknowledge the receipt of your query. Our dedicated support engineer will promptly reach out to you. Kindly take note of your assigned Support Ticket Number for reference.</p>

   <hr/>

   <div class="container">



    

     <form id="submitForm" data-success-modal="#success-modal">

       <input hidden type="text" value="Apr 24 2024 / 04:40 PM;" name="dateTime">

     

       <input hidden  type="text" value="HP PopUP Form" name="fullURL">

       

       <div class="row">

         <div class="col-md-4 col-lg-4 col-sm-12 text-start">
           <label for="ModelNumber">Model Number:</label>
           <input type="text" class="form-control" name="model_num" id="model_num" required>
           <span id="ModelError"></span>
         </div>
         <div class="col-md-4 col-lg-4 col-sm-12 text-start">

             <label for="fullName">Full Name:</label>
             <input type="text" class="form-control" name="fullName" id="full_name" required>
             <span id="NameError"></span>

         </div>

         <div class="col-md-4 col-lg-4 col-sm-12 text-start">

          <label for="phoneNumber">Phone Number:</label>
          <input type="number" class="form-control" name="phoneNumber" id="phone_number" required>
          <span id="PhoneError"></span>

         </div>

       </div>



       <button id="widget_button_new" style="background-color: #0d6efd;color: #fff;border: 1px solid #fff;padding: 11px 20px 10px 20px;border-radius: 5px; margin-top: 9px" class="mt-4">

         Submit</button>

     </form>

   

 </div>



   <!-- <button style="background-color: #0d6efd;color: #fff;border: 1px solid #fff;padding: 11px 20px 10px 20px;border-radius: 5px "><a href="tel:+1 (213)814-2927" class="num"><b>Call Now</b></a></button> -->

     <!--<button id="widget_button_chat" style="background-color: #0d6efd;color: #fff;border: 1px solid #fff;padding: 11px 20px 10px 20px;border-radius: 5px ">-->

     <!--  Chat Now</button>-->
       <button style="background-color: #0d6efd;color: #fff;border: 1px solid #fff;padding: 11px 20px 10px 20px;border-radius: 5px ">

     <a href="https://direct.lc.chat/18387216/" class="num"><b>Chat Now</b></a></button>

</div>







<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<script>

 $(document).ready(function () {

     $("#widget_button_new").click(function (event) {

             $("#initialContent").hide();

             event.preventDefault();
             let numReg = /^[0-9]*$/;

         

             var model_num = $("input[name='model_num']").val();
             var fullName = $("input[name='fullName']").val();
             var phoneNumber = $("input[name='phoneNumber']").val();

           

           if(model_num == '' ){
           
           $("#model_num").focus();
           return false;
           }

           if(fullName == '' ){
               $("#full_name").focus();
               return false;
           }
           if(phoneNumber == ''){
               $("#phone_number").focus(); 
               return false;
           }
           if (phoneNumber.length < 10 || phoneNumber.length > 11 || !numReg.test(phoneNumber)) {
               $("#phone_number").focus(); 
               $("#PhoneError").html("Incorrect Number");
               $("#PhoneError").css("color", "red");
               return false;
           }

               var formData = {

                 model_num: $("input[name='model_num']").val(),
                 fullName: $("input[name='fullName']").val(),
                 phoneNumber: $("input[name='phoneNumber']").val(),
                 model_type: "HP"

               };

             $.ajax({

               type: "POST",

               url: "https://driveprints.net/custom-printing/form-assistance-submit.php",

               data: formData,

               dataType: "json",
               
               success: function (response) {
                   
                     if (response.status === "success") {
                         $("#modalContent").show();
                         $("#submitForm").hide();
                         $("#successMessage").show().text("Your request has been submitted. Ticket Number: " + response.ticketNumber);
                         $("#ticket_no").html(response.ticketNumber);
                     }
                     
                 },error: function () {

                   alert("An error occurred while submitting the form.");

                   }


             });

         

             

             

         });


 });

</script>