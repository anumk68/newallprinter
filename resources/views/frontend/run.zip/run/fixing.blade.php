<!doctype html>

<html lang="en">

<head>

  <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">



  <meta charset="utf-8">

  <meta http-equiv="refresh" content="29999999999999">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="style.css">

  <title>Printer Troubleshooting!</title>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>



  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    /* //button */
    .dropdown {
      border: 1px solid #0d6efd;
      border-radius: 19px !important;
      background: #0d6efd;
      padding: 1px 4px 1px 4px;
      list-style: none !important;
      justify-content: center;
      width: 100%;
      max-width: 165px;
      margin: auto;
      margin-top: 150px !important;
    }

    .dropdown li a.heading {
      color: white !important;
    }

    a.heading {
      margin-left: 17px !important;
    }

    .dropdown.drp_btn ul.dropdown-menu li {
      margin-bottom: 10px;
    }

    .dropdown.drp_btn ul.dropdown-menu {
      width: 95%;
      text-align: center !important;
    }

    a.dropdown-item.nav-link {
      text-align: center !important;
    }

    .jk-btn {

      padding: 5px 30px 5px 30px;
      background-color: #0096d6;

      border: 0px;
      color: #fff;

    }



    .jk-btn:hover {

      padding: 5px 30px 5px 30px;
      background-color: black;

      border: 0px;
      color: #fff;

    }





    p {

      color: #787878;

      font-family: 'Poppins';

    }



    h4,
    h5,
    h6 {

      color: #0d6efd;

      font-weight: 600;

    }









    #pleas {
      display: none;
    }





    #set1 {
      display: none;
    }

    #set2 {
      display: none;
    }

    #set3 {
      display: none;
    }

    #set4 {
      display: none;
    }

    #set5 {
      display: none;
    }

    #set6 {
      display: none;
    }



    #sets7 {
      display: none;
    }

    #showrr {
      display: none;
    }







    #loading-bar-spinner.spinner {

      left: 50%;

      margin-left: -20px;

      top: 50%;

      margin-top: -20px;

      position: absolute;

      z-index: 19 !important;

      animation: loading-bar-spinner 400ms linear infinite;

    }



    #loading-bar-spinner.spinner .spinner-icon {

      width: 40px;

      height: 40px;

      border: solid 4px transparent;

      border-top-color: #00C8B1 !important;

      border-left-color: #00C8B1 !important;

      border-radius: 50%;

    }



    @keyframes loading-bar-spinner {

      0% {
        transform: rotate(0deg);
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
        transform: rotate(360deg);
      }

    }
  </style>



  <script type="text/javascript">

    $(document).ready(function () {





      $('#set1').delay(3000).fadeIn(); $('#set1').delay(3000).fadeOut();

      $('#set2').delay(7000).fadeIn(); $('#set2').delay(4000).fadeOut();

      $('#set3').delay(12000).fadeIn(); $('#set3').delay(3000).fadeOut();

      $('#set4').delay(16000).fadeIn(); $('#set4').delay(4000).fadeOut();

      $('#set5').delay(21000).fadeIn(); $('#set5').delay(3000).fadeOut();

      $('#set6').delay(25000).fadeIn(); $('#set6').delay(6000).fadeOut();

      $('#livechat').delay(5000).fadeIn(); $('#livechat').delay(999999999).fadeOut();





      $('#showrr').delay(27000).fadeIn(); $('#showrr').delay(9999999999999).fadeOut();
      $('#show_err').hide();

      $('#show_err').hide().delay(29000).fadeIn();

      $('#get_btn').hide().delay(31000).fadeIn();





      $('#set7').delay(26000).fadeOut();





    });

  </script>





</head>

<body style="font-family: 'Poppins';">

  <div class="container" id="show_err">
    <!--//New Text-->
    <div class="col">
      <p style="padding:10px 0px 0px 0px;color: #f22840;font-family: 'Poppins';">No Submission Found For This IP
        Address.</p><br>
    </div>
  </div>

  <div class="container " style="padding:50px">

    <div class="row">

      <div id="set7" class="col-12">

        <h5 style="padding-bottom:20px;">Detecting problems</h5>

        <marquee behavior="scroll" scrollamount="15" direction="right"
          style="background-color: #f8f8f8; margin-bottom:10px; "><span
            style="color:#0d6efd; background-color:#0d6efd">HTML marquee...</span></marquee>

        <p id="set1">Gathering information about your devices...</p>

        <p id="set2">Checking the spooler service...</p>

        <p id="set3">checking printer registry files...</p>

        <p id="set4">Checking for a default printer...</p>

        <p id="set5">Checking network printer connectivity...</p>

        <p id="set6">Checking for errors from the printer driver....</p>

      </div>



    </div>

    <div class="row" id="showrr">

      <div class="col-12">
        <img src="{{ asset('public/images/printer-icon-512x512.png') }}" style="width: 50px;">
        <br />
        <span><b style="font-size: 20px;">Error Code <u>0x00000709</u></b></span>
        <p>Registry error found, please check your registry files settings or reinstall drivers.
        </p>
      </div>

      <div id="lets_btn">
        <button id="startButton" class="btn btn-primary" onclick="window.location.href='{{ route('iframe_form') }}'">Let's Starts <i
            class="bi bi-arrow-right-circle-fill"></i></button>
      </div>

      

    </div>

  </div>





  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
    crossorigin="anonymous"></script>
</body>

</html>